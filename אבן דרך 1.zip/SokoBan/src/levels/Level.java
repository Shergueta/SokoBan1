package levels;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import commands.MySokobanPolicy;

public class Level implements Serializable {

	private static final long serialVersionUID = 1L;
	static public final int BOX = '@';
	static public final int TARGET = 'o';
	static public final int WALL = '#';
	static public final int BOXNTARGET = '$';
	static public final int PLAYER = 'A';



	public Level() {

	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static int getBox() {
		return BOX;
	}

	public static int getTarget() {
		return TARGET;
	}

	public static int getWall() {
		return WALL;
	}

	public static int getBoxntarget() {
		return BOXNTARGET;
	}
	private List<Point> boxesList;
	private List<Point> targetsList;
	private List<Point> wallsList;
	private List<Point> boxNtarget;
	private Player player;
	MySokobanPolicy Policy;
	int numOfBoxes;
	int numOfTargets;

	public MySokobanPolicy getPolicy() {
		return Policy;
	}

	public void setPolicy(MySokobanPolicy policy) {
		Policy = policy;
	}

	public List<Point> getBoxesList() {
		return boxesList;
	}

	public List<Point> getTargetsList() {
		return targetsList;
	}

	public List<Point> getWallsList() {
		return wallsList;
	}

	public List<Point> getBoxNtarget() {
		return boxNtarget;
	}


	public Player getplayer() {
		return player;
	}

	public void setBoxesList(List<Point> boxesList){
		this.boxesList=boxesList;
	}
	public void setTargetsList(List<Point> targetsList){
		this.targetsList=targetsList;
	}
	public void setWallsList(List<Point> wallsList){
		this.wallsList=wallsList;
	}
	public void setBoxNtarget(List<Point> boxNtarget) {
		this.boxNtarget = boxNtarget;
	}
	public void setPlayer(Player player){
		this.player=player;
	}

	public int getNumOfBoxes() {
		return numOfBoxes;
	}

	public void setNumOfBoxes(int numOfBoxes) {
		this.numOfBoxes = numOfBoxes;
	}

	public int getNumOfTargets() {
		return numOfTargets;
	}

	public void setNumOfTargets(int numOfTargets) {
		this.numOfTargets = numOfTargets;
	}

	public Level(String level) {
		boxesList = new ArrayList<>();
		targetsList = new ArrayList<>();
		wallsList = new ArrayList<>();
		boxNtarget=new ArrayList<>();

		int x=0,y=0,countBoxs=0,countTagets=0;
		for(int i=0; i <level.length(); i++) {
			switch( level.charAt(i)) {
			case '\n':
				y++;
				x=0;
				break;
			case ' ':
				x++;
				break;
			case WALL:
				wallsList.add(new Point(x++,y));
				break;
			case BOXNTARGET:
				boxNtarget.add(new Point(x,y));
				targetsList.add(new Point(x,y));
				boxesList.add(new Point(x++,y));
				setNumOfBoxes(++countBoxs);
				setNumOfTargets(++countTagets);
				break;
			case BOX:
				boxesList.add(new Point(x++,y));
				setNumOfBoxes(++countBoxs);
				break;
			case TARGET:
				targetsList.add(new Point(x++,y));
				setNumOfTargets(++countTagets);
				break;

			case PLAYER:
				player = new Player(new Point(x++,y));
				break;
			default:
				break;
			}
		}
		if(numOfBoxes!=numOfTargets)
			System.out.println("the num of boxes isnt equal to num of targets");
	}


	public void print(){
		System.out.println("BoxNtarget");
		for(Point item: boxNtarget)
			System.out.println(item.toString());
		System.out.println("Boxes");
		for(Point item: boxesList)
			System.out.println(item.toString());
		System.out.println("Targets");
		for(Point item: targetsList)
			System.out.println(item.toString());
		System.out.println("Walls");
		for(Point item: wallsList)
			System.out.println(item.toString());
		System.out.println("player:");
		System.out.println(player.getCurrentLocation());

	}



	public int getAtLocation(Point point) {
		if (point.compareTo(this.player.getCurrentLocation())==0)
			return PLAYER;
		if( findPointInList(point, boxNtarget) >= 0 )
			return BOXNTARGET;
		if( findPointInList(point, wallsList) >= 0 )
			return WALL;
		if( findPointInList(point, boxesList) >= 0 )
			return BOX;
		if( findPointInList(point, targetsList) >= 0 )
			return TARGET;
		return -1;
	}
	public static int getPlayer() {
		return PLAYER;
	}

	public Point getMax(){
		int xMax=0,yMax=0;
		for(Point item : wallsList)
		{
			if(item.x>xMax)
				xMax=item.x;
			if(item.y>yMax)
				yMax=item.y;
		}
		Point max=new Point(xMax,yMax);

		return max;
	}
	public String getLevelScreen(){

		Point point=getMax();


		String result=new String();
		for(int y=0;y<=point.y;y++){
			String s=new String();
			int r;
			for(int x=0;x<=point.x;x++){
				 r=getAtLocation(new Point(x,y));
				switch(r){
				case WALL:
					s=s+'#';
					break;
				case BOXNTARGET:
					s=s+'$';
					break;
				case BOX:
					s=s+'@';
					break;
				case TARGET:
					s=s+'o';
					break;
				case PLAYER:
					s=s+'A';
					break;
				default:
					s=s+" ";
					break;
				}
			}

			result= result +s+"\n";
		}

		return result;


	}
	public int findPointInList(Point location, List<Point> list) {
		int pos = 0;
		for (Point item : list) {
			if (item.compareTo(location) == 0)
				return pos;
			pos++;
		}
		return -1;
	}

	public void  moveItem(Point currentLocation, String direction,Point newLocation) {

		int pos=0;

		if (getAtLocation(newLocation)== BOX)
		{
			Point after=PointAfter(newLocation, direction);
			if(getAtLocation(after)==TARGET)//�� ������ ����� ������ ��� ����
			{
				pos=findPointInList(newLocation, boxesList);
				boxesList.get(pos).set(after);//����� �� ����� ��������
				boxNtarget.add(after);//����� �� ����� �"������"�

			}
			else{
				pos = findPointInList(newLocation,boxesList);
				if( pos >= 0 )
					this.player.setCurrentLocation(newLocation);//���� �� �����
				switch(direction)	{//���� �� ������ ����� ���������
				case "up":
					boxesList.get(pos).set(new Point(newLocation.x,newLocation.y-1));
					break;
				case "down":
					boxesList.get(pos).set(new Point(newLocation.x,newLocation.y+1));
					break;
				case "right":
					boxesList.get(pos).set(new Point(newLocation.x+1,newLocation.y));
					break; 
				case "left":
					boxesList.get(pos).set(new Point(newLocation.x-1,newLocation.y));
					break;
				}
			}}
		if (getAtLocation(newLocation)== BOXNTARGET)//�� ���� ��� ����..
		{
			pos=findPointInList(newLocation,boxNtarget);
			getBoxNtarget().remove(pos);//����� ���� ������� �� ����� ������ ����� �� ������ ������
			pos=findPointInList(newLocation,boxesList);//���� �� ������ ������ ������� ��� ����� ���� �� �� ���
			getBoxesList().remove(pos);//����� ������� �� ��������... ��"� ����� �� ������ ����
			Point after=PointAfter(newLocation, direction);//���� �� ������ ���� ����� ���� ��� ������
			getBoxesList().add(after);//����� �� ����� �������� �� ����� ��� ������
		}

		this.player.setCurrentLocation(newLocation);//���� �� �����

		if(boxNtarget.size()==targetsList.size())
			System.out.println("level completed!!!!!!!\n");
	}


	public Point PointAfter(Point dest,String direction)
	{
		switch(direction){
		case "up":
			return new Point(dest.getX(),dest.getY()-1);
		case"down":
			return new Point(dest.getX(),dest.getY()+1);
		case "right":
			return new Point(dest.getX()+1,dest.getY());
		case "left":
			return new Point(dest.getX()-1,dest.getY());
		}
		return null;
	}
}



