package levels;

public interface LevelSaver {
	
	void saveLevel();

}
