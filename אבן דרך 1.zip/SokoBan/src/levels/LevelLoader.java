package levels;



public interface LevelLoader {

	Level loadLevel();
}
