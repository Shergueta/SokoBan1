package levels;

import java.io.Serializable;

public class Player implements Serializable{

	private static final long serialVersionUID = 1L;
	private Point currentLocation;

	public Player() {
		// TODO Auto-generated constructor stub
	}
	public Player(Point location) {
        this.currentLocation = location;
    }
    
    public Point getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(Point currentLocation) {
		this.currentLocation = currentLocation;
	}
	boolean move(Level level, int direction ) {
        Point newLocation = currentLocation.move(direction);
        return moveTo(level,newLocation, direction);
    }

    boolean moveTo(Level level, Point newLocation, int direction) {
        if (level.getAtLocation(newLocation) == -1 ||  // Nothing in this location
                level.getAtLocation(newLocation) == Level.TARGET) {
            currentLocation = newLocation;
            return true;
        }

        if (level.getAtLocation(newLocation) == Level.BOX) {
            Box box = new Box(newLocation);
            if (box.move(level, direction)) {
                currentLocation = newLocation;
                return true;
            }
        }
        return false;
    }
}
