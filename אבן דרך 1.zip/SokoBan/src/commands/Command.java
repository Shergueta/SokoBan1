package commands;

public interface Command {

	
	public void execute(); 
	public void setState(String s);
}
