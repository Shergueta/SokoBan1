package commands;

import levels.Level;

public class DisplayReciever extends Receiver{

	
	Level level;
	public DisplayReciever(Level level) {
		this.level=level;
	}
	@Override
	public void Action() {
		
		System.out.println(level.getLevelScreen());
	}

}
