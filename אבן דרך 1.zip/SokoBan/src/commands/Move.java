package commands;

import levels.Level;
import levels.Player;

public class Move extends ConcreteCommand {

	private String direction;
	private Level level;
	private Player player;

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public Level getLevel() {
		return level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public Move(Level level,String direction) {

		this.level=level;
		this.direction=direction;
	}

	public Move(String direction,Level level,Player player){

		this.direction=direction;
		this.level=level;
		this.player=player;


	}

	public Move(Level level,Player player){
	this.level=level;
	this.player=player;
	}

	public void execute() {
		MoveReciever mr= new MoveReciever(this.direction,this.level,this.player);
		mr.Action();
	}

	@Override
	public void setState(String direction) {

		this.direction=direction;
		execute();
		
	}



}
