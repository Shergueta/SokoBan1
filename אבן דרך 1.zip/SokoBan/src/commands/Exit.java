package commands;

import levels.Level;

public class Exit extends ConcreteCommand {

	Level level;
	
	
	@Override
	public void setState(String s) {
		
	}

	@Override
	public void execute() {
		System.exit(0);
	}

}
