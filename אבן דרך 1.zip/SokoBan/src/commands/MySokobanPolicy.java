package commands;

public class MySokobanPolicy {

	public boolean passThroughWall(){ 
		return false; 
	}
	public boolean pushBlockedBox() {
		return false;
	}



}
