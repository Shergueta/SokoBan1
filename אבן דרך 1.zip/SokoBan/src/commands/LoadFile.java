package commands;

import java.io.InputStream;
import java.util.HashMap;

import levels.GeneralLevelLoader;
import levels.Level;
import levels.MyObjectLevelLoader;
import levels.MyTextLevelLoader;
import levels.MyXMLLevelLoader;

public class LoadFile extends Receiver{
	
	private InputStream is;
	private String type;
	private Level level;
	
	public LoadFile(InputStream is, String type) {
		super();
		this.is = is;
		this.type = type;
	}

	public Level getLevel() {
		return level;
	}


	public void setLevel(Level level) {
		this.level = level;
	}

	
	@Override
	public void Action() {
		
			HashMap<String, GeneralLevelLoader> fileTypes=	new HashMap<String, GeneralLevelLoader>();

			fileTypes.put("txt", new MyTextLevelLoader(is));
			fileTypes.put("xml", new MyXMLLevelLoader(is));
			fileTypes.put("obj", new MyObjectLevelLoader(is));
			
			this.level= fileTypes.get(type).loadLevel();
			 
		}

}
